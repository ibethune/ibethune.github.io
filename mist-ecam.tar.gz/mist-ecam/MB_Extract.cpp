//
//
// CopyRight Anton Martinsson, 2017, not to be distributed freely
//
//

//====================== MB FORCE EVALUATION ===========================//

void MercBenz::compute_pair_force(Particle* PartI,
				  Particle* PartJ,
				  const double& r,
				  const double& r_x,
				  const double& r_y,
				  double& V)
{
  // Lennard Jones Foxrce and Potential
  LJ_force(PartI,PartJ,r,r_x,r_y);
  V += LJ_potential(r);

  // ------------------------------ HYDROGEN BOND ----------------------------------- //

  // Helpers and derivatives with respect to x and y
  std::vector<double> h_i(3,0.0);
  std::vector<double> h_j(3,0.0);
  
  std::vector<double> dh_i_dx_i(3,0.0);
  std::vector<double> dh_j_dx_i(3,0.0);
   
  std::vector<double> dG_dh_i(3,0.0);
  std::vector<double> dG_dh_j(3,0.0);

  std::vector<double> dh_i_dy_i(3,0.0);
  std::vector<double> dh_j_dy_i(3,0.0);

  std::vector<double> dh_i_dQ_00(3,0.0);
  std::vector<double> dh_i_dQ_01(3,0.0);

  std::vector<double> dh_i_dQ_10(3,0.0);
  std::vector<double> dh_i_dQ_11(3,0.0);

  std::vector<double> dh_j_dQ_00(3,0.0);
  std::vector<double> dh_j_dQ_01(3,0.0);

  std::vector<double> dh_j_dQ_10(3,0.0);
  std::vector<double> dh_j_dQ_11(3,0.0);

  double dphiHB_dx = 0.0;
  double dphiHB_dy = 0.0;

  double dphiHB_dQ_i_00 = 0.0;
  double dphiHB_dQ_i_01 = 0.0;

  double dphiHB_dQ_i_10 = 0.0;
  double dphiHB_dQ_i_11 = 0.0;

  double dphiHB_dQ_j_00 = 0.0;
  double dphiHB_dQ_j_01 = 0.0;

  double dphiHB_dQ_j_10 = 0.0;
  double dphiHB_dQ_j_11 = 0.0;

  // derivatives with respect to r
  double dG_dr = -(r-r_HB) / (Sigma_HB*Sigma_HB) * G(r-r_HB);
  double dr_dx = -r_x/r;
  double dr_dy = -r_y/r;
  
  // unit vector in r direction 
  std::vector<double> u(2,0.0);
  u[0] = r_x/r;
  u[1] = r_y/r;

  // Assign the values from above
  for(unsigned k=0;k<3;k++)
    {
      // h_i
      h_i[k] = 
	((*PartI->Q_pt(0,0)) * PartI->arm(0,k) + (*PartI->Q_pt(1,0)) * PartI->arm(1,k)) * u[0] +
	((*PartI->Q_pt(0,1)) * PartI->arm(0,k) + (*PartI->Q_pt(1,1)) * PartI->arm(1,k)) * u[1];
	

       // h_j
       h_j[k] = 
	 ((*PartJ->Q_pt(0,0)) * PartJ->arm(0,k) + (*PartJ->Q_pt(1,0)) * PartJ->arm(1,k)) * u[0] +
	 ((*PartJ->Q_pt(0,1)) * PartJ->arm(0,k) + (*PartJ->Q_pt(1,1)) * PartJ->arm(1,k)) * u[1];
	       
       // dG_dh_i
       dG_dh_i[k] = 
	 -(h_i[k] - 1.0) / (Sigma_HB * Sigma_HB) * G(h_i[k] - 1.0);

       // dG_dh_j
       dG_dh_j[k] = 
	 -(h_j[k] + 1.0) / (Sigma_HB * Sigma_HB) * G(h_j[k] + 1.0);

       // dh_i_dx_i
       dh_i_dx_i[k] = 
	 r_x * h_i[k] / (r * r) 
	 - ((*PartI->Q_pt(0,0)) * PartI->arm(0,k) + (*PartI->Q_pt(1,0)) * PartI->arm(1,k)) / r;

       // dh_j_dx_i
       dh_j_dx_i[k] = 
	 r_x * h_j[k] / (r * r) 
	 - ((*PartJ->Q_pt(0,0)) * PartJ->arm(0,k) + (*PartJ->Q_pt(1,0)) * PartJ->arm(1,k)) / r;

       // dh_i_dy_i
       dh_i_dy_i[k] = 
	 r_y * h_i[k] / (r * r)
	 - ((*PartI->Q_pt(0,1)) * PartI->arm(0,k) + (*PartI->Q_pt(1,1)) * PartI->arm(1,k)) / r;

       // dh_j_dy_i
       dh_j_dy_i[k] = 
	 r_y * h_j[k] / (r * r)
	 - ((*PartJ->Q_pt(0,1)) * PartJ->arm(0,k) + (*PartJ->Q_pt(1,1)) * PartJ->arm(1,k)) / r;

       // matrix elements for the Torque particle I
       dh_i_dQ_00[k] = u[0] *  PartI->arm(0,k);
       dh_i_dQ_01[k] = u[1] *  PartI->arm(0,k);

       dh_i_dQ_10[k] = u[0] *  PartI->arm(1,k);
       dh_i_dQ_11[k] = u[1] *  PartI->arm(1,k);

       // matrix elements for the Torque particle J
       dh_j_dQ_00[k] = u[0] *  PartJ->arm(0,k);
       dh_j_dQ_01[k] = u[1] *  PartJ->arm(0,k);

       dh_j_dQ_10[k] = u[0] *  PartJ->arm(1,k);
       dh_j_dQ_11[k] = u[1] *  PartJ->arm(1,k);
     }

   // k over the arms
   for(unsigned k=0;k<3;k++)
     {
       for(unsigned l=0;l<3;l++)
	 {
	   // ---------------- HYDROGEN BOND LINEAR --------------- //
	   dphiHB_dx += 
	       Epsilon_HB * dG_dr     * dr_dx         * G(h_i[k]-1.0) * G(h_j[l]+1.0)
	     + Epsilon_HB * G(r-r_HB) * dG_dh_i[k]    * dh_i_dx_i[k]  * G(h_j[l]+1.0)
	     + Epsilon_HB * G(r-r_HB) * G(h_i[k]-1.0) * dG_dh_j[l]    * dh_j_dx_i[l];
	   
	   dphiHB_dy +=
	       Epsilon_HB * dG_dr     * dr_dy         * G(h_i[k]-1.0) * G(h_j[l]+1.0)
	     + Epsilon_HB * G(r-r_HB) * dG_dh_i[k]    * dh_i_dy_i[k]  * G(h_j[l]+1.0)
	     + Epsilon_HB * G(r-r_HB) * G(h_i[k]-1.0) * dG_dh_j[l]    * dh_j_dy_i[l];
	   
	   // --------------- HYDROGEN BOND TORQUE I -------------- //
	   dphiHB_dQ_i_00 += 
	     Epsilon_HB * G(r-r_HB) * dG_dh_i[k] * dh_i_dQ_00[k] * G(h_j[l]+1.0);

	   dphiHB_dQ_i_01 +=
	     Epsilon_HB * G(r-r_HB) * dG_dh_i[k] * dh_i_dQ_01[k] * G(h_j[l]+1.0);

	   dphiHB_dQ_i_10 += 
	     Epsilon_HB * G(r-r_HB) * dG_dh_i[k] * dh_i_dQ_10[k] * G(h_j[l]+1.0);

	   dphiHB_dQ_i_11 += 
	     Epsilon_HB * G(r-r_HB) * dG_dh_i[k] * dh_i_dQ_11[k] * G(h_j[l]+1.0);

	   // --------------- HYDROGEN BOND TORQUE J -------------- //
	   dphiHB_dQ_j_00 +=
	     Epsilon_HB * G(r-r_HB) * G(h_i[k]-1.0) * dG_dh_j[l] * dh_j_dQ_00[l];  
	   
	   dphiHB_dQ_j_01 +=
	     Epsilon_HB * G(r-r_HB) * G(h_i[k]-1.0) * dG_dh_j[l] * dh_j_dQ_01[l];  
	   
	   dphiHB_dQ_j_10 +=
	     Epsilon_HB * G(r-r_HB) * G(h_i[k]-1.0) * dG_dh_j[l] * dh_j_dQ_10[l];  
	   
	   dphiHB_dQ_j_11 +=
	     Epsilon_HB * G(r-r_HB) * G(h_i[k]-1.0) * dG_dh_j[l] * dh_j_dQ_11[l];  

	   // ---------------- HYDROGEN POTENTIAL --------------- //
	   V += Epsilon_HB * G(r - r_HB) * G(h_i[k]-1) * G(h_j[l]+1);
	 }				      
     }

   // add force for particle I
#pragma omp atomic
   *PartI->f_pt(0) -= 2.0 * dphiHB_dx;
   
#pragma omp atomic
   *PartI->f_pt(1) -= 2.0 * dphiHB_dy;
   
   // add force for particle J
#pragma omp atomic
   *PartJ->f_pt(0) += 2.0 * dphiHB_dx;
   
#pragma omp atomic
   *PartJ->f_pt(1) += 2.0 * dphiHB_dy;
   
   // add torque to overall torque
#pragma omp atomic
   *PartI->tau_pt(0) +=
     *PartI->Q_pt(0,1) * dphiHB_dQ_i_00 + *PartI->Q_pt(1,1) * dphiHB_dQ_i_10
     - *PartI->Q_pt(0,0) * dphiHB_dQ_i_01 - *PartI->Q_pt(1,0) * dphiHB_dQ_i_11;
   
#pragma omp atomic
   *PartJ->tau_pt(0) += 
     *PartJ->Q_pt(0,1) * dphiHB_dQ_j_00 + *PartJ->Q_pt(1,1) * dphiHB_dQ_j_10
     - *PartJ->Q_pt(0,0) * dphiHB_dQ_j_01 - *PartJ->Q_pt(1,0) * dphiHB_dQ_j_11;
};

//========================== INTEGRATOR STEPS IN DLM-BAOAB ALGORITHM

 // A step - particle
  void A_step(Particle* part, 
	      const double& step_size,
	      const unsigned& dim)
  {
    double* q;
    double  p = 0.0;
    double  m = 0.0;

    // loop over the number of dimensions
    for(unsigned j=0;j<dim;j++)
      {
	q =  part->q_pt(j);
	p = *part->p_pt(j);
	m = *part->m_pt(j);

	*q += step_size * Time_Step * p/m;
      }
  };

  // B step - particle
  void B_step(Particle* part, 
	      const double& step_size,
	      const unsigned& dim)
  {
    double* p;
    double  f = 0.0;

    // loop over the number of dimensions
    for(unsigned j=0;j<dim;j++)
      {
	p =  part->p_pt(j);
	f = *part->f_pt(j);

	*p += step_size * Time_Step * f;
      }
  };

  // O step - particle
  void O_step(Particle* part, 
	      const double& step_size,
	      const unsigned& dim,
	      const double& kT)
  {
    double* p;
    double  m  = 0.0;

    double c   = exp(-Gamma * step_size * Time_Step);
    
    // loop over the number of dimensions
    for(unsigned j=0;j<dim;j++)
      {
	p =  part->p_pt(j);
	m = *part->m_pt(j);
	
	*p = c * (*p) + sqrt((1 - c*c) * kT)
	  * sqrt(m) *gsl_ran_gaussian(r,1.0);
      }

  };

  // Bphi step, changes angular momentum
  void BpPhi_step(Particle* part,const double& step_size)
  {
    *part->pi_pt(0) += step_size * Time_Step * (*part->tau_pt(0));
  };
  
  // ApPhi step, changes angular momentum
  void ApPhi_step(Particle* part,const double& step_size)
  {
    // R is Rotation counter clockwise of angle alpha
    double alpha = step_size*Time_Step*(*part->pi_pt(0))/(*part->I_pt(0));

    // R = [  Cos(alpha) Sin(alpha)
    //       -Sin(alpha) Cos(alpha) ]
    double R_00 =  cos(alpha);
    double R_01 = -sin(alpha);

    double R_10 =  sin(alpha);
    double R_11 =  cos(alpha);

    // Update the rotation matrix
    //     Q = QR^T
    double Q_00 = *part->Q_pt(0,0)*R_00 + *part->Q_pt(0,1)*R_01;
    double Q_01 = *part->Q_pt(0,0)*R_10 + *part->Q_pt(0,1)*R_11;
    double Q_10 = *part->Q_pt(1,0)*R_00 + *part->Q_pt(1,1)*R_01;
    double Q_11 = *part->Q_pt(1,0)*R_10 + *part->Q_pt(1,1)*R_11;

    // Asign the new matrix
    *part->Q_pt(0,0) = Q_00;
    *part->Q_pt(0,1) = Q_01;

    *part->Q_pt(1,0) = Q_10;
    *part->Q_pt(1,1) = Q_11;
 };

//============================= INTEGRATOR FUNCTIONS CALLING ABOVE
void pre_force_integration(Particle* PartPt,
			   const unsigned& dim,
			   const double& kT)
{
  Integrator<SYSTEM>::B_step(PartPt,0.5,dim);
  Integrator<SYSTEM>::A_step(PartPt,0.5,dim);
  Integrator<SYSTEM>::O_step(PartPt,1.0,dim,kT);
  Integrator<SYSTEM>::A_step(PartPt,0.5,dim);
  
  if(dim != 1)
    {
      // Integrate angular momentum forward
      Integrator<SYSTEM>::BpPhi_step(PartPt,0.5);
      
	// Integrate rotation forward
      Integrator<SYSTEM>::ApPhi_step(PartPt,1.0);
    }
};

void post_force_integration(Particle* PartPt,
			    const unsigned& dim)
{
  Integrator<SYSTEM>::B_step(PartPt,0.5,dim);
	  
  if(dim != 1)
    {
      // integrate angular momentum forward
      Integrator<SYSTEM>::BpPhi_step(PartPt,0.5);
      }
};
